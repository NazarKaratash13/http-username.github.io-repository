<!DOCTYPE html>
<html>
<head>
    <title>PHP Calculator</title>
</head>
<body>
    <h1>PHP Calculator</h1>
    <input type="text" id="equationInput" placeholder="Enter equation">
    <button onclick="solveEquation()">Solve</button>
    <p id="result">Result: </p>

    <script>
        function solveEquation() {
            const input = document.getElementById('equationInput').value;

            fetch('/solve.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded'
                },
                body: 'equation=' + encodeURIComponent(input)
            })
            .then(response => response.text())
            .then(data => {
                const resultElement = document.getElementById('result');
                resultElement.textContent = `Result: ${data}`;
            })
            .catch(error => {
                console.error('Error:', error);
            });
        }
    </script>
</body>
</html>
