<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $equation = $_POST['equation'];

    try {
        $result = eval("return $equation;");
        echo $result;
    } catch (Exception $e) {
        echo 'Error';
    }
}
?>
