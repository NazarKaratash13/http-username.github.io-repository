const equationInput = document.getElementById("equationInput");
const clearButton = document.getElementById("clearButton");
const solutionResult = document.getElementById("solutionResult");

function appendToInput(value) {
  equationInput.value += value;
}

function clearInput() {
  equationInput.value = "";
  solutionResult.textContent = "-";
}

function solveEquation() {
  try {
    const equation = equationInput.value;
    const result = solveForX(equation);
    solutionResult.textContent = result;
  } catch (error) {
    console.error(error);
    solutionResult.textContent = "Ошибка";
  }
}

function solveForX(equation) {
  const solutions = nerdamer.solveEquations(equation, 'x');
  let result = "x = ";
  solutions.forEach((solution, index) => {
    result += solution.text();
    if (index < solutions.length - 1) {
      result += ", ";
    }
  });
  return result;
}

// Навешиваем обработчики событий 
clearButton.addEventListener('click', clearInput);

const buttons = document.getElementsByClassName("button");

for (let i = 0; i < buttons.length; i++) {
   const button = buttons[i];
   const action = button.getAttribute("data-action");
   
   button.addEventListener('click', () => {
       if (action === "=") {
           solveEquation();
       } else {
           appendToInput(action);
       }
   });
}
