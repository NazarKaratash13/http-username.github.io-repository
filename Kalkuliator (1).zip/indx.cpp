#include <iostream>
#include <boost/math/tools/roots.hpp>
#include <symengine/expression.h>
#include <symengine/solvers.h>

using namespace std;
namespace tools = boost::math::tools;
namespace sym = SymEngine;

// Функция для вычисления значения уравнения
double equation(double x) {
    return x * x - 4; // Пример уравнения: x^2 - 4
}

// Функция для символьного решения уравнения
void solveSymbolicEquation() {
    sym::Symbol x("x");
    sym::RCP<sym::Basic> equation = x * x - 4;

    std::vector<sym::RCP<const sym::Basic>> solutions;
    sym::solve(sym::vec_basic{equation}, sym::vec_basic{x}, solutions);

    for (const auto& sol : solutions) {
        std::cout << "Solution: " << sol << std::endl;
    }
}

int main() {
    // Решение численным методом с помощью Boost.Math
    double result;
    tools::eps_tolerance<double> tol(30);
    boost::uintmax_t max_iter = 100;
    std::pair<double, double> r = tools::bisect(equation, -10.0, 10.0, tol, max_iter);

    if (r.second == max_iter) {
        cout << "Failed to converge" << endl;
    } else {
        result = 0.5 * (r.first + r.second);
        cout << "Root: " << result << endl;
    }

    // Символьное решение с помощью SymEngine
    cout << "Symbolic solutions:" << endl;
    solveSymbolicEquation();

    return 0;
}
